﻿unit WebModuleUnit1;

interface

uses
  System.SysUtils, System.Classes, System.IOUtils, System.StrUtils,
  Web.HTTPApp,
  Web.WebFileDispatcher,
  FireDAC.Stan.Intf, FireDAC.Stan.Option, FireDAC.Stan.Error,
  FireDAC.UI.Intf, FireDAC.Phys.Intf, FireDAC.Stan.Def,
  FireDAC.Stan.Pool, FireDAC.Stan.Async,
  FireDAC.Phys, FireDAC.Phys.IB, FireDAC.Phys.IBDef,
  FireDAC.Phys.IBBase, FireDAC.VCLUI.Wait,
  Data.DB, FireDAC.Comp.Client, FireDAC.Comp.DataSet, FireDAC.DApt,
  FireDAC.Stan.Param, FireDAC.DatS, FireDAC.DApt.Intf;

type
  TWebModule1 = class(TWebModule)
    FDConnection1: TFDConnection;
    FDPhysIBDriverLink1: TFDPhysIBDriverLink;
    WebFileDispatcher1: TWebFileDispatcher;
    FDQuery1: TFDQuery;
    procedure WebModuleCreate(Sender: TObject);
    procedure WebModuleBeforeDispatch(Sender: TObject; Request: TWebRequest;
      Response: TWebResponse; var Handled: Boolean);
  private
    function RenderProjectList: string;
    procedure SaveProject(Request: TWebRequest);
    procedure DeleteProject(const AID: string);
    procedure ConfigureStaticDispatcher;
  public
  end;

var
  WebModuleClass: TComponentClass = TWebModule1;

implementation

{$R *.dfm}

{============================================
  INICIALIZACIÓN DEL MÓDULO
============================================}
procedure TWebModule1.WebModuleCreate(Sender: TObject);
begin
  FDConnection1.LoginPrompt := False;
  FDConnection1.Params.Values['User_Name'] := 'SYSDBA';
  FDConnection1.Params.Values['Password'] := 'masterkey';

  FDConnection1.Connected := True;

  ConfigureStaticDispatcher;

  FDQuery1.Connection := FDConnection1;
  FDQuery1.SQL.Clear;
end;

procedure TWebModule1.ConfigureStaticDispatcher;
var
  Root: string;
begin
  Root := TPath.Combine(TPath.GetDirectoryName(ParamStr(0)), 'wwwroot');
  WebFileDispatcher1.RootDirectory := Root;
  WebFileDispatcher1.DefaultFile := 'datos.html';
end;

{============================================
  ROUTER (solo /debug /projects)
============================================}
procedure TWebModule1.WebModuleBeforeDispatch(Sender: TObject; Request: TWebRequest;
  Response: TWebResponse; var Handled: Boolean);
var
  action, id: string;
begin
  // (Opcional) /debug -> ver qué llega
  if SameText(Request.PathInfo, '/debug') then
  begin
    Response.ContentType := 'text/plain; charset=utf-8';
    Response.Content := 'Method=' + Request.Method + sLineBreak +
                        'Path=' + Request.PathInfo + sLineBreak +
                        'ContentType=' + Request.ContentType + sLineBreak +
                        'Content=' + Request.Content + sLineBreak +
                        'Fields=' + Request.ContentFields.Text;
    Handled := True;
    Exit;
  end;

  // /projects
  if SameText(Request.PathInfo, '/projects') then
  begin
    Response.ContentType := 'text/html; charset=utf-8';

    if SameText(Request.Method, 'GET') then
    begin
      Response.Content := RenderProjectList;
      Handled := True;
      Exit;
    end;

    if SameText(Request.Method, 'POST') then
    begin
      action := Request.ContentFields.Values['action'];

      if SameText(action, 'delete') then
      begin
        id := Request.ContentFields.Values['PROJ_ID'];
        DeleteProject(id);
      end
      else
        SaveProject(Request);

      Response.Content := RenderProjectList;
      Handled := True;
      Exit;
    end;
  end;
end;

{============================================
  LISTA
============================================}
function TWebModule1.RenderProjectList: string;
var
  sb: TStringBuilder;
  id, name_, prod_: string;
begin
  sb := TStringBuilder.Create;
  try
    FDQuery1.Close;
    FDQuery1.SQL.Text :=
      'SELECT PROJ_ID, PROJ_NAME, PRODUCT ' +
      'FROM PROJECT ORDER BY PROJ_ID';

    try
      FDQuery1.Open;
    except
      on E: Exception do
      begin
        Result :=
          '<div class="alert alert-danger mt-3">ERROR SQL: ' + E.Message + '</div>';
        Exit;
      end;
    end;

    sb.Append('<div class="table-responsive mt-2">');
    sb.Append('<table class="table table-striped table-hover align-middle">');
    sb.Append('<thead class="table-light"><tr>');
    sb.Append('<th>ID</th><th>Nombre</th><th>Producto</th>');
    sb.Append('<th class="text-end">Acciones</th></tr></thead><tbody>');

    FDQuery1.First;
    while not FDQuery1.Eof do
    begin
      id := FDQuery1.FieldByName('PROJ_ID').AsString;
      name_ := FDQuery1.FieldByName('PROJ_NAME').AsString;
      prod_ := FDQuery1.FieldByName('PRODUCT').AsString;

      sb.Append('<tr>');
      sb.Append('<td><code>' + id + '</code></td>');
      sb.Append('<td>' + name_ + '</td>');
      sb.Append('<td>' + prod_ + '</td>');
      sb.Append('<td class="text-end">');

      // Botón editar
      sb.Append('<button class="btn btn-sm btn-outline-secondary me-2" ');
      sb.Append('onclick="edit(''' + id + ''',''' +
        StringReplace(name_, '''', '''''', [rfReplaceAll]) + ''',''' +
        StringReplace(prod_, '''', '''''', [rfReplaceAll]) + ''')">Editar</button>');

      // Borrar
      sb.Append('<button class="btn btn-sm btn-danger" ');
      sb.Append('hx-post="/projects" ');
      sb.Append('hx-vals=''{"action":"delete","PROJ_ID":"' + id + '"}'' ');
      sb.Append('hx-target="#list" hx-swap="innerHTML" ');
      sb.Append('hx-confirm="¿Seguro que deseas borrar ' + id + '?"');
      sb.Append('>Borrar</button>');

      sb.Append('</td></tr>');

      FDQuery1.Next;
    end;

    sb.Append('</tbody></table></div>');
    Result := sb.ToString;
  finally
    sb.Free;
    FDQuery1.Close;
  end;
end;

{============================================
update
============================================}

procedure TWebModule1.SaveProject(Request: TWebRequest);
begin
  FDQuery1.Close;

  // UPDATE (si el registro existe)
  FDQuery1.SQL.Text :=
    'UPDATE PROJECT SET PROJ_NAME = :N, PRODUCT = :P WHERE PROJ_ID = :ID';

  FDQuery1.ParamByName('ID').AsString := Request.ContentFields.Values['PROJ_ID'];
  FDQuery1.ParamByName('N').AsString  := Request.ContentFields.Values['PROJ_NAME'];
  FDQuery1.ParamByName('P').AsString  := Request.ContentFields.Values['PRODUCT'];

  FDQuery1.ExecSQL;

  // Si no actualizó nada → hacer INSERT
  if FDQuery1.RowsAffected = 0 then
  begin
    FDQuery1.SQL.Text :=
      'INSERT INTO PROJECT (PROJ_ID, PROJ_NAME, PRODUCT)' +
      ' VALUES (:ID, :N, :P)';
    FDQuery1.ExecSQL;
  end;
end;


procedure TWebModule1.DeleteProject(const AID: string);
begin
  FDQuery1.Close;
  FDQuery1.SQL.Text := 'DELETE FROM PROJECT WHERE PROJ_ID = :ID';
  FDQuery1.ParamByName('ID').AsString := AID;
  FDQuery1.ExecSQL;
end;

end.


